package com.atm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.atm.model.Account;
import com.atm.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountService service;
	
	@GetMapping
	public List<Account> ListAccounts(){
		return service.ListAccounts();
	}
	
	@GetMapping("/{accountId}")
	public Account GetAccount(@PathVariable Long accountId){
		return service.GetAccount(accountId);
	}
	
	@GetMapping("/{account_number}/{password}")
	public Account Login(@PathVariable Double account_number, @PathVariable String password){
		return service.Login(account_number, password);
	}
	
	@PostMapping("/{clientId}")
	@ResponseStatus(HttpStatus.CREATED)
	public Account AddAccount(@RequestBody Account account, @PathVariable Long clientId) {
		return service.AddAccount(account, clientId);
	}
}
