package com.atm.model;

import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
@Table(name = "TB_ACCOUNT")
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long account_id;
	
	@Column(nullable = false)
	private Double number;
	
	@Column(nullable = false)
	private Float current_currency;
	
	@Column(nullable = false)
	private Float overdraw_limit;
	
	@Column(nullable = false)
	private String account_password;
	
	@Column(nullable = false)
	private Boolean active;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="client_id", referencedColumnName = "client_id")
	@JsonBackReference
    private Client client;
	
	@OneToMany(mappedBy = "account")
	@JsonManagedReference
	private List<Transaction> transactions;

	public long getAccount_id() {
		return account_id;
	}

	public void setAccount_id(long account_id) {
		this.account_id = account_id;
	}

	public Double getNumber() {
		return number;
	}

	public void setNumber(Double number) {
		this.number = number;
	}

	public Float getCurrent_currency() {
		return current_currency;
	}

	public void setCurrent_currency(Float current_currency) {
		this.current_currency = current_currency;
	}

	public Float getOverdraw_limit() {
		return overdraw_limit;
	}

	public void setOverdraw_limit(Float overdraw_limit) {
		this.overdraw_limit = overdraw_limit;
	}

	public String getAccount_password() {
		return account_password;
	}

	public void setAccount_password(String account_password) {
		this.account_password = account_password;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public int hashCode() {
		return Objects.hash(account_id, account_password, active, client, current_currency, number, overdraw_limit,
				transactions);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		return account_id == other.account_id && Objects.equals(account_password, other.account_password)
				&& Objects.equals(active, other.active) && Objects.equals(client, other.client)
				&& Objects.equals(current_currency, other.current_currency) && Objects.equals(number, other.number)
				&& Objects.equals(overdraw_limit, other.overdraw_limit)
				&& Objects.equals(transactions, other.transactions);
	}

}
