package com.atm.model;

import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "TB_CLIENT")
public class Client {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long client_id;
	
	@Column(nullable = false)
	private String nome;
	
	@Column(nullable = false)
	private String rg;
	
	@Column(nullable = false)
	private String cpf;
	
	@Column(nullable = false)
	private String endereco_rua;
	
	@Column(nullable = false)
	private String endereco_numero;
	
	@Column(nullable = false)
	private String endereco_cep;
	
	private String endereco_complemento;
	
	@Column(nullable = false)
	private Boolean active;
	
	@OneToMany(mappedBy = "client")
	@JsonManagedReference
	private List<Account> acounts;
	
	public long getClient_id() {
		return client_id;
	}

	public void setClient_id(long client_id) {
		this.client_id = client_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEndereco_rua() {
		return endereco_rua;
	}

	public void setEndereco_rua(String endereco_rua) {
		this.endereco_rua = endereco_rua;
	}

	public String getEndereco_numero() {
		return endereco_numero;
	}

	public void setEndereco_numero(String endereco_numero) {
		this.endereco_numero = endereco_numero;
	}

	public String getEndereco_cep() {
		return endereco_cep;
	}

	public void setEndereco_cep(String endereco_cep) {
		this.endereco_cep = endereco_cep;
	}

	public String getEndereco_complemento() {
		return endereco_complemento;
	}

	public void setEndereco_complemento(String endereco_complemento) {
		this.endereco_complemento = endereco_complemento;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public List<Account> getAcounts() {
		return acounts;
	}

	public void setAcounts(List<Account> acounts) {
		this.acounts = acounts;
	}

	@Override
	public int hashCode() {
		return Objects.hash(acounts, active, client_id, cpf, endereco_cep, endereco_complemento, endereco_numero,
				endereco_rua, nome, rg);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		return Objects.equals(acounts, other.acounts) && Objects.equals(active, other.active)
				&& client_id == other.client_id && Objects.equals(cpf, other.cpf)
				&& Objects.equals(endereco_cep, other.endereco_cep)
				&& Objects.equals(endereco_complemento, other.endereco_complemento)
				&& Objects.equals(endereco_numero, other.endereco_numero)
				&& Objects.equals(endereco_rua, other.endereco_rua) && Objects.equals(nome, other.nome)
				&& Objects.equals(rg, other.rg);
	}
}
