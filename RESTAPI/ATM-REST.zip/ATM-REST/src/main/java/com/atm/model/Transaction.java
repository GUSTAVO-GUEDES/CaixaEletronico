package com.atm.model;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "TB_TRANSACTION")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transaction_id;
	
	@Column(nullable = false)
	private String transaction_type;
	
	@Column(nullable = false)
	private Float trasaction_value;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="account_id", referencedColumnName = "account_id")
	@JsonBackReference
	private Account account;

	
	public Float getTrasaction_value() {
		return trasaction_value;
	}

	public void setTrasaction_value(Float trasaction_value) {
		this.trasaction_value = trasaction_value;
	}

	public long getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(long transiction_id) {
		this.transaction_id = transiction_id;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public int hashCode() {
		return Objects.hash(account, transaction_id, transaction_type, trasaction_value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		return Objects.equals(account, other.account) && transaction_id == other.transaction_id
				&& Objects.equals(transaction_type, other.transaction_type)
				&& Objects.equals(trasaction_value, other.trasaction_value);
	}
}
