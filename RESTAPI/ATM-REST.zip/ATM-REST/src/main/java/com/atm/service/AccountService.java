package com.atm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atm.model.Account;
import com.atm.model.Client;
import com.atm.repository.AccountRepository;
import com.atm.repository.ClientRepository;

@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private ClientRepository clientRepository;
	
	public List<Account> ListAccounts() {
		return accountRepository.findAll();
	}
	
	public Account GetAccount(Long id) {		
		return accountRepository.findById(id).get();
	}
	
	public Account AddAccount(Account account, Long clientId) {
		Account new_account = accountRepository.save(account);
		Client client = clientRepository.findById(clientId).get();
		
		new_account.setClient(client);
		
		return accountRepository.save(new_account);
	}
	
	public Account Login(Double account_number, String password) {
		Account account = accountRepository.accountLogin(account_number, password);
		
		return account;
	}
	
	public Account removeClientToAccount(Long accountId,Long clientId) {
		Account account = accountRepository.findById(accountId).get();
		
		account.setClient(null);
		return accountRepository.save(account);
	}
}
