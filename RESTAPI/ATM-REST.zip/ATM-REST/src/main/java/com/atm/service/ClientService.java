package com.atm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atm.model.Client;
import com.atm.repository.ClientRepository;

@Service
public class ClientService {
	@Autowired
	private ClientRepository clientRepository;
	
	public List<Client> ListClients(){
		return clientRepository.findAll();
	}
	
	public Client GetClient(Long id){
		return clientRepository.findById(id).get();
	}
	
	public Client AddClient(Client client) {
		return clientRepository.save(client);
	}
}
