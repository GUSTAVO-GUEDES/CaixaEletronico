package com.atm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atm.model.Account;
import com.atm.model.Transaction;
import com.atm.repository.AccountRepository;
import com.atm.repository.TransactionRepository;

@Service
public class TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	public List<Transaction> ListTransaction(){
		return transactionRepository.findAll();
	}
	
	public void CommitTransaction(Transaction transaction, Account account) {
		switch(transaction.getTransaction_type()) {
			case "Saque":
				Float current_currency_saque = account.getCurrent_currency();
				Float valor_saque = transaction.getTrasaction_value();
				
				Float valor_final = current_currency_saque - valor_saque;
				
				account.setCurrent_currency(valor_final);
				
				accountRepository.save(account);
				break;
			case "Deposito":
				Float current_currency_deposito = account.getCurrent_currency();
				Float valor_deposito = transaction.getTrasaction_value();
				
				Float valor_final_deposito = current_currency_deposito + valor_deposito;
				
				account.setCurrent_currency(valor_final_deposito);
				
				accountRepository.save(account);
				
				break;
		}
	}
	
	public Transaction AddTransaction(Transaction transaction, Long account_id) {
		Account account = accountRepository.findById(account_id).get();
		
		Transaction new_transaction = transactionRepository.save(transaction);
		new_transaction.setAccount(account);
		
		this.CommitTransaction(new_transaction, account);
		
		return transactionRepository.save(new_transaction);
	}
}
